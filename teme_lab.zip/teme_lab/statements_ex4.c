#include "headers.h"

int prime(int x)
{
    if( x == 0 || x == 1)
        return 0;
    for(int d = 2; d*d <=x; d++)
        if(x % d == 0)
            return 0;
    return 1;
}

int mainex4()
{
    puts("Give n:");
    int n;
    scanf("%d", &n);
    for(int i = 2; i<=n; i++)
        if(prime(i))
            printf("%d ", i);
    return 0;
}

