#include "headers.h"

void extract(char s[], char d[], int poz, int len)
{
    int k = 0;
    while(s[poz] && k < len)
        d[k++] = s[poz++];
    d[k]='\0';
}
int ex2()
{
    char c[30],d[30];
    gets(c);
    extract(c,d,0, strlen(c));
    puts(d);
    return 0;
}
