#include "headers.h"

int n, arr[101], s[101], k;

void print1(int x)
{
    for(int i = 0; i < x; i++)
        printf("%d ", s[arr[i]]);
    puts("\n");
}

int ok1(int x)
{
    for(int i = 0; i < x ; i++)
        if(arr[i] >= arr[x])
            return 0;
    return 1;
}

void back1(int x)
{
    for(int i = 0; i < n; i++)
    {
        arr[x] = i;
        if(ok1(x))
            if(x == k-1)
                print1(k);
            else
                back1(x+1);
    }
}
void readArr1(int *n, int arr[])
{
    scanf("%d", n);
    for(int i = 0 ; i < *n; i++)
        scanf("%d", &arr[i]);
}
void ex6()
{
    puts("Give the the number of elements and the set A:");
    readArr1(&n, s);
    puts("Give k:");
    scanf("%d", &k);
    back1(0);

}
