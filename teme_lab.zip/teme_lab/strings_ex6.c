#include "headers.h"

void intToChar(int x, char c[])
{
    int mir = 0,k =0;
    while(x)
    {
        mir = mir * 10 + x % 10;
        x /= 10;
    }
    while(mir)
    {
        c[k++] = mir % 10 + '0';
        mir /= 10;
    }
    c[k] = '\0';
}

void charToInt(int *x, char c[])
{
    *x = 0;
    int i = 0;
    while(c[i])
    {
        *x = *x * 10 + c[i] - '0';
        i++;
    }
}
