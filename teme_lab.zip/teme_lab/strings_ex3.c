#include "headers.h"

void insertAt(char c[], int poz, char ch)
{
    char x[30];
    strcpy(x, c+poz);
    strcpy(c+poz+1, x);
    c[poz] = ch;
}
