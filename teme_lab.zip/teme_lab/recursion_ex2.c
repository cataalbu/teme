#include "headers.h"

int nonrecHermite(int x, int n)
{
    int a = 1, b = 2 * x, c;
    if(n == 0)
        return a;
    if (n == 1)
        return b;
    for(int i = 2; i <= n; i++)
    {
        c = 2 * i * b - 2 * (i - 1) * a;
        a = b;
        b = c;
    }
    return b;
}
int recHermite(int x, int n)
{
    if(n == 0)
        return 1;
    else if(n == 1)
        return 2 * x;
        else return 2 * n * recHermite(x,n-1) - 2 * (n - 1) * recHermite(x,n-2);
}
