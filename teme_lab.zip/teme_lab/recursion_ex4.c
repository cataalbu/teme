#include "headers.h"

void readWords(int n)
{
    if(n>0)
    {
        char c[31];
        gets(c);
        readWords(n-1);
        puts(c);
    }
}
