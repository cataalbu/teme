#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    int code;
    float amount, ppu;
    char name[31], unit[31];
}item;

///Strings
int ex2();
void insertAt(char c[], int poz, char ch);
void intToChar(int x, char c[]);
void charToInt(int *x, char c[]);
void deleteSubstring(char c[], int poz, int len);

///Recursion
int nonrecHermite(int x, int n);
int recHermite(int x, int n);
void readWords(int n);
void ex6();
void ex8();
int mainack();

///Files
void prod_ex2();
void prod_ex3();
void prod_ex4();
void files_ex6();

///Statements
int mainex4();
int mainex5();
int mainex6();
