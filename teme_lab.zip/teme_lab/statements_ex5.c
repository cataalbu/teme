#include "headers.h"

int prime1(int x)
{
    if( x == 0 || x == 1)
        return 0;
    for(int d = 2; d*d <=x; d++)
        if(x % d == 0)
            return 0;
    return 1;
}

int mainex5()
{
    puts("Give n:");
    int n;
    scanf("%d", &n);

    int i;
    for( i = 1; i*i<=n; i++);
    puts("The greatest perfect square less or equal to n is:");
    printf("%d\n", (i-1)*(i-1));
    while(prime1(n) == 0)
        n++;
    puts("The least prime number greater or equal to n  is:");
    printf("%d", n);
    return 0;
}
