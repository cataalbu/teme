#include "headers.h"


int n, arr[101], s[101];

void print()
{
    for(int i = 0; i < n; i++)
        printf("%d ", s[arr[i]]);
    puts("\n");
}

int ok(int k)
{
    for(int i = 0; i < k ; i++)
        if(arr[i] == arr[k])
            return 0;
    return 1;
}

void back(int k)
{
    for(int i = 0; i < n; i++)
    {
        arr[k] = i;
        if(ok(k))
            if(k == n-1)
                print();
            else
                back(k+1);
    }
}
void readArr(int *n, int arr[])
{
    scanf("%d", n);
    for(int i = 0 ; i < *n; i++)
        scanf("%d", &arr[i]);
}
void ex8()
{
    puts("Give the the number of elements and the set A:");
    readArr(&n, s);
    back(0);

}
