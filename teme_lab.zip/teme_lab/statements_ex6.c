#include "headers.h"

int mainex6()
{
    int n, cn, ok = 0, og = 0;
    puts("Give n:");
    scanf("%d", &n);
    cn = n;
    while(cn)
    {
        og = og * 10 + cn % 10;
        cn /= 10;
    }
    if(n == og)
        puts("The number is a palindrome");
    else
        puts("The number is not a palindrome");
    return 0;
}
