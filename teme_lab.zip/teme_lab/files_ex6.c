#include "headers.h"

void readIn()
{
    char ch;
    FILE *fp = fopen("file.dat", "w");
    puts("Give the input you want to write in the file (end with Ctrl+Z) :");
    while((ch = getc(stdin))!=EOF)
        putc(ch, fp);
    fclose(fp);
}

void displayFile()
{
    FILE *fp = fopen("file.dat", "r");
    char data[101];
    int i = 1;
    while(fgets(data,100,fp)!=(char *)0)
   	{
		printf("%d  %s", i, data);
    	i++;
   	}
 	fclose(fp);
}

void files_ex6()
{
    readIn();
    displayFile();
}
