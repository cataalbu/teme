#include "headers.h"

void deleteSubstring(char c[], int poz, int len)
{
    strcpy(c + poz, c + poz + len);
}
