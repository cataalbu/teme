#include "headers.h"

item prod[5];
void populateProd()
{
    strcpy(prod[0].name,"portocale");
    prod[0].code = 110;
    strcpy(prod[0].unit, "kg");
    prod[0].amount = 3;
    prod[0].ppu = 3.96;

    strcpy(prod[1].name, "lapte");
    prod[1].code = 100;
    strcpy(prod[1].unit, "l");
    prod[1].amount = 1;
    prod[1].ppu = 4.89;

}

void prod_ex2()
{
    populateProd();
    FILE *fp;
    fp = fopen("products.txt", "w");
    fprintf(fp, "%d\n", 2);
    for(int i =0; i < 2; i++)
        fprintf(fp, "%s\n%d\n%.2f %s %.2f\n", prod[i].name, prod[i].code, prod[i].amount, prod[i].unit, prod[i].ppu);
    fclose(fp);
}

void prod_ex3()
{
    FILE *fin;
    FILE * fout;
    fin = fopen("products.txt", "r");
    fout = fopen("arranged.txt", "w");

    item prods[31];
    int n;
    fscanf(fin, "%d", &n);
    fgetc(fin);
    for(int i =0; i < n; i++)
    {
        fgets(prods[i].name,31,fin);
        fscanf(fin, "%d %f", &prods[i].code, &prods[i].amount);
        fscanf(fin, "%s",prods[i].unit);
        fscanf(fin, "%f", &prods[i].ppu);
        fgetc(fin);

    }

    for(int i = 0; i < n-1; i++)
        for(int j = i+1; j < n; j++)
        {
            if(prods[i].code>prods[j].code)
            {
                char c[31];
                strcpy(c,prods[i].name);
                strcpy(prods[i].name,prods[j].name);
                strcpy(prods[j].name,c);

                strcpy(c,prods[i].unit);
                strcpy(prods[i].unit,prods[j].unit);
                strcpy(prods[j].unit,c);

                int x = prods[i].code;
                prods[i].code = prods[j].code;
                prods[j].code = x;

                float y = prods[i].amount;
                prods[i].amount = prods[j].code;
                prods[j].amount = y;

                y = prods[i].ppu;
                prods[i].ppu = prods[j].ppu;
                prods[j].ppu = y;

            }
        }

    for(int i =0; i < n; i++)
       {
            fprintf(fout, "%s%d\n%.2f %s %.2f\n", prods[i].name, prods[i].code, prods[i].amount, prods[i].unit, prods[i].ppu);
       }

    fclose(fin);
    fclose(fout);
}



void addProduct(item * p)
{
    FILE *fa = fopen("products.txt", "a");
FILE *fr = fopen("products.txt", "r+");
    int n;
    fscanf(fr,"%d", &n);
    fseek(fr,0, SEEK_SET);
    //fscanf(fa,"%d", &n);
    n++;
    //fgetc();
    gets(((p)->name));
    scanf("%d %f",&((p)->code), &((p)->amount));
    scanf("%s",((p)->unit));
    scanf("%f", &((p)->ppu));
    fprintf(fr, "%d", n);
    fprintf(fa, "%s\n%d\n%.2f %s %.2f\n",((p)->name) , ((p)->code), ((p)->amount), ((p)->unit), ((p)->ppu));
    fclose(fa);
    fclose(fr);
}
void prod_ex4()
{
    item p;
   addProduct(&p);
}
