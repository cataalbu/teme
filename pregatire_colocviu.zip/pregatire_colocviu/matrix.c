
#include "functionsHeader.h"

///Basic functions with matrices


///Matrix declaration

int ** matDec(int n, int m)
{
    int **mat;
    mat = (int **)calloc(n, sizeof(int *));
    for(int i = 0; i < n; i++)
        *(mat + i) = (int *)calloc(m, sizeof(int));

    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            mat[i][j] = 0;
    return mat;
}

///Function that reads a matrix from the console

void matRead(int n, int m, int *** mat)
{
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            scanf("%d", &(*(*(*mat + i) + j)));
}


///Function that prints a matrix to the console

void matPrint(int n, int m, int ** mat)
{
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < m; j++)
            printf("%d ", *(*(mat +i) + j));
        printf("\n");
    }
}

///Function that adds up two matrices and return the sum matrix

int ** matSum(int n, int m, int ** ma, int ** mb)
{
    int ** mc;
    mc = matDec(n, m);
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            *(*(mc + i) + j) = *(*(ma + i) + j) + *(*(mb + i) + j);
    return mc;
}

///Function that makes the extraction of two matrices

int ** matDif(int n, int m, int ** ma, int ** mb)
{
    int ** mc;
    mc = matDec(n, m);
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            *(*(mc + i) + j) = *(*(ma + i) + j) - *(*(mb + i) + j);
    return mc;
}


///Matrix multiplication

int ** matMult(int m1, int m2, int n1, int n2, int ** mat1, int ** mat2)
{

    int ** res;
    res = matDec(m1,n2);
    for (int i = 0; i < m1; i++)
    {
        for (int j = 0; j < n2; j++)
        {
            res[i][j] = 0;
            for (int x = 0; x < m2 ; x++)
            {
                *(*(res + i) + j) += *(*(mat1 + i) + x) * *(*(mat2 + x) + j);
            }
        }
    }
    return res;
}


///Function that frees up the memory occupied by a matrix

void freeMat(int n, int ** mat)
{
    for(int i = 0; i < n; i++)
        free(mat + i);
    free(mat);
}


