#include <stdio.h>
#include <stdlib.h>

/*
    Exercitiile cu pointeri sunt in  matrix.c si in array.c si in functionsHeader.h
    Ex 2 si ex 3 din fisier
*/


///Exercises from functions lab document
void ex5();
void ex10();
void ex13();
void ex14();

///Exercises from structures and unions
void ex3();
void ex6();
