#include "headers.h"
#include "structures.h"

int main()
{
    ex10();
    return 0;
}
