#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define M_PI   3.141593
#include <string.h>

typedef struct{
    int day,month,year;
}date;

typedef struct {
    char name[101], address[101];
    date birthDate;
}student;


typedef struct
{
    float radius, area;
} circle;
typedef struct
{
    float l1,l2,l3,area;
}triangle;
typedef struct
{
    float l, L, area;
}rectangle;
typedef struct
{
    float l, area;
}square;
typedef union
{
    char name[30];
    circle c;
    triangle t;
    rectangle r;
    square s;
}figure;
