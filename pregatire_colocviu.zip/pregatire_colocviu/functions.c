#include "functionsHeader.h"

void ex5()
{
    int n;
    puts("Give n:");
    scanf("%d",&n);
    int **A, ** B, ** C, **D;
    B = matDec(n,n);
    C = matDec(n,n);
    puts("Give matrix B:");
    matRead(n,n,&B);
    puts("Give matrix C:");
    matRead(n,n,&C);
    puts("Matrix A:");
    D = matSum(n, n , B, C);
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            *(*(D + i) + j) *= 2;
    B = matMult(n, n, n, n, B, C);
    A = matDif(n, n, B, D);
    matPrint(n, n, A);
    freeMat(n, A);
    freeMat(n, B);
    freeMat(n, C);
    freeMat(n, D);
}

int nrOfBank(int amount)
{
    int bank[] = {1, 5, 10, 50, 100, 200, 500};
    int s = 0, i = 6;
    while(amount > 0)
    {
        while(amount - bank[i] >= 0)
        {
            amount = amount - bank[i];
            s++;
        }
        i--;
    }
    return s;
}
void ex10()
{
    int amount;
    puts("Enter amount of money in RON:");
    scanf("%d",&amount);
    printf("The minimum amount of banknotes for the amount %d is %d banknotes \n", amount, nrOfBank(amount));

}

int perfectSquare(int n)
{
    int s = (int)sqrt(n);
    if(s * s == n)
        return 1;
    else return 0;
}

int* perfectSquareArray(int n, int* arr, int* len)
{
   int i = 0;
   int* res = arrDec(1);
   for(int k = 0; k < n; k++)
   {
       if(perfectSquare(arr[k])==1)
       {
           i++;
           res = realloc(res, i*sizeof(int));
           res[i-1] = arr[k];
       }
   }
   *len = i;
   return res;
}

void ex13()
{
    int n, len;
    int *arr, *res;
    puts("Give n:");
    scanf("%d", &n);
    arr = arrDec(n);
    puts("Give the array:");
    arrRead(n, &arr);
    res = perfectSquareArray(n, arr, &len);
    puts("The elements that are a perfect square are:");
    arrPrint(len, res);

}

void ex14()
{
    int n, i = 1;
    puts("Give n:");
    scanf("%d", &n);
    while(i*i <= n)
        i++;
    i--;
    printf("The bigest perfect square less or equal to %d is %d", n, i*i);

}
