
int arrElMult(int n, int * a, int * b);
