#include "structures.h"

void readStud(int n, student ** stud)
{
    for(int i = 0; i < n; i++)
    {
        gets (&(*((*stud + i)->name)));
       // gets (stud[i].name);
        scanf("%d", &((*stud + i)->birthDate.day));
        scanf("%d", &((*stud + i)->birthDate.month));
        scanf("%d", &((*stud + i)->birthDate.month));
        getchar();
        gets(&(*((*stud + i)->address)));
    }

}
void printStud(int n, student * stud)
{
    for(int i = 0; i < n; i++)
    {
        printf("%s \n",(stud+i)->name);
        printf("%d.",(stud+i)->birthDate.day);
        printf("%d.",(stud+i)->birthDate.month);
        printf("%d \n",(stud+i)->birthDate.year);
        printf("%s \n",(stud+i)->address);
    }
        //printf("%s",(stud+i)->name);
//        printf("%s %d.%d.%d %s", ((stud + i)->name),*((stud + i)->birthDate->day),*((stud + i)->birthDate->month),*((stud + i)->birthDate->year), *((stud + i)->address));
}

void lexicoSorting(int n, student * stud)
{
    for(int i = 0; i < n -1; i++)
        for(int j = i + 1; j < n; j++)
            if(strcmp((stud+i)->name,(stud+j)->name) > 0)
            {
                char c[101];
                strcpy(c,(stud+i)->name);
                strcpy((stud+i)->name,(stud+j)->name);
                strcpy((stud+j)->name,c);

                strcpy(c,(stud+i)->address);
                strcpy((stud+i)->address,(stud+j)->address);
                strcpy((stud+j)->address,c);

                int x;
                x = (stud+i)->birthDate.day;
                (stud+i)->birthDate.day = (stud+j)->birthDate.day;
                (stud+j)->birthDate.day = x;
                x = (stud+i)->birthDate.month;
                (stud+i)->birthDate.month = (stud+j)->birthDate.month;
                (stud+j)->birthDate.month = x;
                x = (stud+i)->birthDate.year;
                (stud+i)->birthDate.year = (stud+j)->birthDate.year;
                (stud+j)->birthDate.year = x;

            }
}

void ex3()
{
    int n;
    puts("Give number of students:");
    scanf("%d", &n);
    getchar();
    student *students;
    students = (student*)calloc(n, sizeof(student));
    puts("Give students(name, DD MM YYYY, address):");
    readStud(n, &students);
    lexicoSorting(n, &stud);
   // printf("%d",(students+1)->birthDate.day);
    printStud(n, students);


}
void circleArea(circle * c)
{
    c->area = c->radius * c->radius * M_PI ;
}

void triangleArea(triangle * t)
{
    float l1 = t->l1, l2 = t->l2,l3 = t->l3, p;
    p = (l1 + l2 + l3)/2;
    t->area = sqrt(p*(p-l1)*(p-l2)*(p-l3));
}
void rectangleArea(rectangle * r)
{
    r->area =  r->L*r->l;
}
void squareArea(square * s)
{
    s->area = s->l*s->l;
}
void ex6()
{

    figure f;
    puts("Give the figure:");
    gets(f.name);
    if(strcmp(f.name, "circle") == 0)
    {
        puts("Give radius:");
        scanf("%f", &(f.c.radius));
        circleArea(&f.c);
        puts("The area:");
        printf("%f",f.c.area);
    }
    if(strcmp(f.name, "triangle") == 0)
    {
        puts("Give edges:");
        scanf("%f %f %f", &(f.t.l1), &(f.t.l2), &(f.t.l3));
        triangleArea(&f.t);
        printf("%f",f.t.area);
    }
    if(strcmp(f.name, "square") == 0)
    {
        puts("Give edge:");
        scanf("%f", &(f.s.l));
        squareArea(&f.s);
        puts("The area:");
        printf("%f",f.s.area);
    }
    if(strcmp(f.name, "rectangle") == 0)
    {
        puts("Give edges:");
        scanf("%f %f", &(f.r.l), &(f.r.L));
        rectangleArea(&f.r);
        puts("the area:");
        printf("%f",f.r.area);
    }
}

