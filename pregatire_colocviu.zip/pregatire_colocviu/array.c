#include <stdio.h>
#include <stdlib.h>

int* arrDec(int n)
{
    int *arr;
    arr = (int*)calloc(n, sizeof(int));
    for(int i = 0; i < n; i++)
        *(arr + i) = 0;
    return arr;
}

void arrRead(int n, int ** arr)
{
    for(int i = 0; i < n; i++)
        scanf("%d", &((*arr)[i]));
}
void arrPrint(int n, int * arr)
{
    for(int i = 0; i < n; i++)
        printf("%d ", *(arr + i));
}
int arrElMult(int n, int * a, int * b)
{
    int sum = 0;
    for(int i = 0; i < n; i++)
        sum += a[i] * b[i];
    return sum;
}
void arrSort(int n, float * a)
{
    float t;
      for (i = 0; i < n; i++) {

        for (j = i + 1; j < n; j++) {

            if (*(a + j) < *(a + i)) {

                t = *(a + i);
                *(a + i) = *(a + j);
                *(a + j) = t;
            }
        }
    }
}
