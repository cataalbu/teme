#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int ** matDec(int n, int m);
void matRead(int n, int m, int *** mat);
void matPrint(int n, int m, int ** mat );
int ** matSum(int n, int m, int **ma, int ** mb);
int ** matMult(int na, int ma, int nb, int mb, int ** mat1, int ** mat2);
int ** matDif(int n, int m, int ** ma, int ** mb);
void freeMat(int n, int ** mat);




int * arrDec(int n);
void arrRead(int n, int ** arr);
void arrPrint(int n, int * arr);

